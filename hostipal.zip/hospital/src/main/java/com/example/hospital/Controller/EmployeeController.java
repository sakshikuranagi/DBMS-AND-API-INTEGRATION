package com.example.hospital.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.hospital.Entity.Employee;
import com.example.hospital.Repository.EmployeeRepository;

@RestController
@RequestMapping("employee")
public class EmployeeController {
	@Autowired
	EmployeeRepository empRep;
	
	@GetMapping
	public String getall() {
		String result="";
		for(Employee e:empRep.findAll()) {
			result += "Name:"+e.getName()+"|"+"Position:"+e.getPosition()+"|"+"Hire Date:"+e.getHireDate()+"<br>";
			
		}
		return result;
		
	}
	@GetMapping("/{id}")
    public String getEmployeeById(@PathVariable Long id) {
		Employee e=empRep.findById(id).orElse(null);
		return"Name:"+e.getName()+"|"+"Position:"+e.getPosition()+"|"+"Hire Date:"+e.getHireDate()+"<br>";
	}
	@PostMapping("/add")
	public Employee addEmployee(@RequestBody Employee employee) {
		return empRep.save(employee);
	}
	@PostMapping("/update/{id}")
	public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
		Employee emp = empRep.findById(id).orElse(null);
		emp.setName(employee.getName());
		emp.setPosition(employee.getPosition());
		emp.setHireDate(employee.getHireDate());
		return empRep.save(emp);
	}
	@DeleteMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable Long id) {
		empRep.deleteById(id);
		return "Employee Deleted";
	}
}
