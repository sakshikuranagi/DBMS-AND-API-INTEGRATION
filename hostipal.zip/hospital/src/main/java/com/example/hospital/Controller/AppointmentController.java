package com.example.hospital.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.hospital.Entity.Appointment;
import com.example.hospital.Repository.AppointmentRepository;
import com.example.hospital.Repository.DoctorRepository;

@RestController
@RequestMapping("/appointment")
public class AppointmentController {

    @Autowired
    private AppointmentRepository appRep;

    @Autowired
    private DoctorRepository docRep;


    @GetMapping
    public String getAllAppointments() {
        String result = "";

        for (Appointment a : appRep.findAll()) {
            result += "ID:" + a.getId() + "|" +
                      "Patient:" + a.getPatient().getName() + "|" +
                      "Doctor:" + a.getDoctor().getName() + "|" +
                      "Appointment Date:" + a.getAppointmentDate() + "|" +
                      "Appointment Time:" + a.getAppointmentTime() + "|" +
                      "Details:" + a.getDetails() + "<br>";
        }
        return result;
    }

    
    @GetMapping("/{id}")
    public String getAppointmentById(@PathVariable Long id) {
        Appointment a = appRep.findById(id).orElse(null);

        if (a == null) {
            return "Appointment not found";
        }

        return "ID:" + a.getId() + "|" +
               "Patient:" + a.getPatient().getName() + "|" +
               "Doctor:" + a.getDoctor().getName() + "|" +
               "Appointment Date:" + a.getAppointmentDate() + "|" +
               "Appointment Time:" + a.getAppointmentTime() + "|" +
               "Details:" + a.getDetails();
    }

   
    @PostMapping
    public Appointment addAppointment(@RequestBody Appointment appointment) {
        return appRep.save(appointment);
    }

   
    @PutMapping("/{id}")
    public ResponseEntity<Appointment> updateAppointment(
            @PathVariable Long id,
            @RequestBody Appointment aDetails) {

        Appointment a = appRep.findById(id).orElse(null);

        if (a == null) {
            return ResponseEntity.notFound().build();
        }

        a.setPatient(aDetails.getPatient());
        a.setDoctor(aDetails.getDoctor());
        a.setAppointmentDate(aDetails.getAppointmentDate());
        a.setAppointmentTime(aDetails.getAppointmentTime());
        a.setDetails(aDetails.getDetails());

        Appointment updatedAppointment = appRep.save(a);
        return ResponseEntity.ok(updatedAppointment);
    }

    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAppointment(@PathVariable Long id) {

        return appRep.findById(id).map(appointment -> {

            appointment.getPatient().removeAppointment(appointment);
            appointment.getDoctor().removeAppointment(appointment);
            appRep.delete(appointment);

            return ResponseEntity.ok().build();

        }).orElse(ResponseEntity.notFound().build());
    }
}